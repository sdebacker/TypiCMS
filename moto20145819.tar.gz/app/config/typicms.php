<?php
return App::make('TypiCMS\Modules\Settings\Repositories\SettingInterface')->getAllToArray();
