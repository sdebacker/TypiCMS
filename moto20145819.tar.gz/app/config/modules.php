<?php 
/*
|--------------------------------------------------------------------------
| Modules list for select/option in a menu item
|--------------------------------------------------------------------------
*/
return [
    'Blocks',
    'Categories',
    'Contacts',
    'Events',
    'Files',
    'Galleries',
    'Groups',
    'Menus',
    'News' ,
    'Pages',
    'Partners',
    'Places',
    'Projects',
    'Tags',
    'Translations',
    'Users',
];
