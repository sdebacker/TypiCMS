<?php 
/*
|--------------------------------------------------------------------------
| Modules list for sitemap generation
|--------------------------------------------------------------------------
*/
return [
    'modules' => [
        'Pages',
        'Partners',
        'Places',
        'Projects',
        'Events',
        'Galleries',
        'News' ,
    ]
];
