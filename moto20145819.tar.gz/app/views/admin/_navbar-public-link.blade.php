{{ link_to($model->getPublicUri(), ucfirst(trans('global.view website'))) }}
