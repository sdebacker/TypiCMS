<a href="{{ route('admin.' . $table . '.index') }}" title="{{ trans($table . '::global.Back') }}">
    <span class="text-muted fa fa-arrow-circle-left"></span><span class="sr-only">{{ trans($table . '::global.Back') }}</span>
</a>
