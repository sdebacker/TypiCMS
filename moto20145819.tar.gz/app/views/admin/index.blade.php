@section('main')

@include($module . '.admin.index')

@stop
