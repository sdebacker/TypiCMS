{{ Notification::showAll('<div class="alert alert-:type">:message</div>') }}
